/*
 * Interface
 * contains a method "draw" 
 */

package PRN_0018;

public interface Drawable {

	public abstract void draw();
}
