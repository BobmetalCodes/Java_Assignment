package student;

public class Main {
public static void main(String []args){
		student s1= new student();
		//student s3= new student();
		//student s4= new student(3,"spider",60.09f);
		System.out.println(args);
		s1.Display();
		student.showcount();
	}
}

