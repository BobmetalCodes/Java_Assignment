package student;

public class student {
	private int rollno;
	private String name;
	private float percentage;
	private static int count;
	
	
	public student()     //Default Constructor
	{
		rollno=1;
		name="ajay";
		percentage=70.1f;
		count++;
	}
	
	public student(int no,String n,float p)  //Parameterized Constructor
	{
		rollno=no;
		name=n;
		percentage=p;
		count++;
	}
	
	
	static {           //this block execute only once used for initiazation of count
		count=0;
	}
	
	void Display()
	{
		System.out.println("Name"+name);
		System.out.println("Roll_No"+rollno);
		System.out.println("Percentage"+percentage);
		
	}
	public static void showcount()
	{
		System.out.println("No of Objects:="+count);
		
	}
	
	
	
	
}
