package Lab_Exam;

import java.util.Scanner;
public class Main {

	public static void main(String[] args) {
		
		Movie []a1=new Movie[10];
		for(int i=0; i<a1.length; i++)
		{
			a1[i]=new Movie();
		}
		while(true)
		{
			System.out.println("enter your choice");
			System.out.println("1.add Movie record");
			System.out.println("2.display Movie record");
			Scanner s2=new Scanner(System.in);
			int choice=s2.nextInt();
		
		switch(choice)
		{
		case 1:
		for (int i = 0; i < a1.length; i++) {
			a1[i].add_movie_rec();
		}
		break;
		case 2:
			for (int j = 0; j < a1.length; j++) {
				a1[j].display();
			}
		break;
	   }

	}
}
}
