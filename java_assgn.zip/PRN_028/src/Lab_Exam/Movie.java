package Lab_Exam;
import java.util.Scanner;
public class Movie {
	private int movieID;
	private String movieNmae;
	private int movieRating;
	Scanner s1=new Scanner(System.in);
	
	
	public Movie(int movieID, String movieNmae, int movieRating) {
		this.movieID = movieID;
		this.movieNmae = movieNmae;
		this.movieRating = movieRating;
	}
	
	public Movie() {
		
	}

	public int getMovieID() {
		return movieID;
	}
	public void setMovieID(int movieID) {
		this.movieID = movieID;
	}
	public String getMovieNmae() {
		return movieNmae;
	}
	public void setMovieNmae(String movieNmae) {
		this.movieNmae = movieNmae;
	}
	public int getMovieRating() {
		return movieRating;
	}
	public void setMovieRating(int movieRating) {
		this.movieRating = movieRating;
	}
	
	
	public void add_movie_rec()
	{
		System.out.println("Enter Movie ID");
		this.movieID=s1.nextInt();
		
		
		System.out.println("Enter Movie Name");
		this.movieNmae=s1.nextLine()+s1.nextLine();
		
		
		System.out.println("Enter Movie Rating");
		this.movieRating=s1.nextInt();
		
		
	}
	public void display()
	{
		System.out.println("Movie Id="+movieID);
		System.out.println("Movie Name="+movieNmae);
		System.out.println("Movie Rating="+movieRating);
		System.out.println("");
	}

}
