package concrete;

public interface Drawable {
	public void method();
}
