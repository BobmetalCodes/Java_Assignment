package concrete;

import java.util.ArrayList;
import java.util.Iterator;

public class TestConcrete {
	public static void main(String[] args) {
		
		ArrayList<ConcreteClass> list = new ArrayList<ConcreteClass>();
		
		for (int i = 0; i < 5 ; i++) {
			list.add(new ConcreteClass());
		}
		
		Iterator<ConcreteClass> iter = list.iterator();
		
		for(ConcreteClass i : list) {
			i.method();
		}
	}

}
