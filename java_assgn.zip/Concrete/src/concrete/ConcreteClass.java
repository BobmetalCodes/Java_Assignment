package concrete;

public class ConcreteClass implements Drawable{
	public ConcreteClass() {
	
	}
	
	@Override
	public void method() {
		System.out.println("This is method definition");
		
	}

}
