package initblocks;

public class TestInitBlocks {

	public static void main(String[] args) {
		
		new InitBlocks();
		new InitBlocks();

	}
}
