package Movie;

public class Movies {
	private int movieId;
	private String movieName;
	private float movieRating;
	
	
	public Movies() {
		this.movieId = 1;
		this.movieName = "Jay HOO";
		this.movieRating =3.5f;
	}
	public Movies(int movieId, String movieName, float movieRating) {
		this.movieId = movieId;
		this.movieName = movieName;
		this.movieRating = movieRating;
	}
	public int getMovieId() {
		return movieId;
	}
	public void setMovieId(int movieId) {
		this.movieId = movieId;
	}
	public String getMovieName() {
		return movieName;
	}
	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}
	public float getMovieRating() {
		return movieRating;
	}
	public void setMovieRating(float movieRating) {
		this.movieRating = movieRating;
	}
	public void printDetails()
	{
		System.out.println("Movie id="+movieId);
		System.out.println("Movie name="+movieName);
		System.out.println("Movie Rating="+movieRating);
		
	}
	@Override
	public String toString() {
		return "Movies [movieId=" + movieId + ", movieName=" + movieName + ", movieRating=" + movieRating + "]";
	}
	

	
	
	
	
	
	

}
