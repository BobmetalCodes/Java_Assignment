package Movie;

public abstract interface Drawable {
		public void printdetails();
	}
