package Movie;
import java.util.Scanner;
import java.util.ArrayList;
public class Movie1 {

	public static void main(String[] args) {
	Scanner scan=new Scanner(System.in);//Scanner function
	System.out.println("enter the number of movies details ");
	Movies []m=new Movies[scan.nextInt()];//array of movie object
	ArrayList<Movies> list= new ArrayList<>();//list of node
	
	for(int i=0; i<m.length; i++)
			{
				m[i]=new Movies();
			}
	
	while(true)
	{
	System.out.println("0.exit");
	System.out.println("1.Insert the movie information");
	System.out.println("2.Display Movie Details");
	System.out.println("3.add movie node into list");
	System.out.println("4.display the list");
	System.out.println("enter a choice");
	int choice=scan.nextInt();
	switch(choice)
	{
	case 1:
	     int l=0;
	     for(Movies k: m) {
		 m[l].setMovieId(scan.nextInt());
		 m[l].setMovieName(scan.nextLine()+scan.nextLine());
		 m[l].setMovieRating(scan.nextFloat());
		 l++;
	    }
	     break;
	case 2:
		int p=0;
		for(Movies j: m) {
		System.out.println(m[p++].toString());
	}
		break;
	
	case 3:
		Movies m1=new Movies(scan.nextInt(),scan.nextLine()+scan.nextLine(),scan.nextInt());
		list.add(m1);
		break;
	case 4:
		for(Movies e5:list) {
			e5.printDetails();
			}
		break;
	case 0:
		System.exit(0);
		break;
	}
	
	}
	
	}
	
}

