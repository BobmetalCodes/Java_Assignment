package Interface;

public interface Printable {

	public void print();
}
