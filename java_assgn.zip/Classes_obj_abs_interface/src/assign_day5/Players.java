package assign_day5;

public class Players {

	String name;

	public Players() {

	}

	public Players(String name) {
		this.name = name;
	}

	public void printName() {
		System.out.println("Name= " + name);
	}

}
