package assign_day5;

public interface Printable {
	public void printDetails();
}
