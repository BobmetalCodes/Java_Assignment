package list;

import java.util.ArrayList;
import java.util.Iterator;

public class ListArr {
	public static void main(String[] args) {
		ArrayList arr = new ArrayList();

		arr.add(1);
		arr.add(2);
		arr.add(3.0f);
		System.out.println(arr);

		arr.remove(new Integer(6));
		System.out.println(arr);

		ArrayList<String> strlist = new ArrayList<String>();

		strlist.add("John");
		strlist.add("Jane");
		strlist.add("Jack");

		System.out.println(strlist);

		Iterator<String> iter = strlist.iterator();

		for (String string : strlist) {
			System.out.println(string);
		}

		while (iter.hasNext())
			System.out.println(iter.next());
	}
}
